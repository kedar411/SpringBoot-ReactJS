# Spring Boot Web Application
## Configuring Spring Boot for MySQL
This repository has the project files for a blog post about configuring Spring Boot to work with MySQL. You can find the full post on my website [Spring Framework Guru](https://springframework.guru/configuring-spring-boot-for-mysql/)